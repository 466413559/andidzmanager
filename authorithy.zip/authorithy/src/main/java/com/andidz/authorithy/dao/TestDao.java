package com.andidz.authorithy.dao;

public class TestDao {
}
